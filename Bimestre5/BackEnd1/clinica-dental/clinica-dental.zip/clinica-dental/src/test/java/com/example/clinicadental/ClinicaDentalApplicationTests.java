package com.example.clinicadental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaDentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
