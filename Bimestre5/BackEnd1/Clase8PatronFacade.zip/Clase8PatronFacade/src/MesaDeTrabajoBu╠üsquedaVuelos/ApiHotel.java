package MesaDeTrabajoBúsquedaVuelos;

public class ApiHotel {
    public String BuscarServicioViaje(Hotel hotel){
        return "Estamos buscando su hotel" + hotel;
    }
}
