package MesaDeTrabajoBúsquedaVuelos;

public class ApiVuelo {
    public String BuscarServicioViaje(Vuelo vuelo){
        return "Estamos buscando su vuelo" + vuelo;
    }

}
