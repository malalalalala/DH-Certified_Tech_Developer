package MesaDeTrabajoBúsquedaVuelos;

public interface IBuscador {
    public abstract void BuscarServicioViaje(Vuelo vuelo, Hotel hotel);
}
