package com.dh.clase23.dao;

import com.dh.clase23.dominio.Domicilio;
import com.dh.clase23.dominio.Paciente;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Component
public class PacienteDAOH2 implements IDao<Paciente>{
    @Override
    public List<Paciente> listarElementos() {
        Connection connection=null;
        List<Paciente> listaPacientes= new ArrayList<>();
        Paciente paciente=null;
        Domicilio domicilio=null;
        try{
            connection=H2Aux.getConnection();
            PreparedStatement ps= connection.prepareStatement("SELECT *" +
                    " FROM PACIENTES");
            ResultSet rs= ps.executeQuery();
            while (rs.next()){
                DomicilioDAOH2 domicilioDAOH2= new DomicilioDAOH2();
                domicilio=domicilioDAOH2.buscarXId(rs.getInt(7));
                paciente=new Paciente(rs.getInt(1),
                        rs.getString(2),rs.getString(3),
                        rs.getString(4),rs.getInt(5),
                        rs.getDate(6).toLocalDate(),domicilio
                        );
                //ahora tenemos que agregarlo al listado
                listaPacientes.add(paciente);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            try{
                connection.close();
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
        }
        return listaPacientes;
    }

    @Override
    public Paciente buscarXCriterio(String email) {
        Connection connection=null;
        Paciente paciente=null;
        Domicilio domicilio=null;
        try{
            connection=H2Aux.getConnection();
            PreparedStatement ps= connection.prepareStatement("SELECT *" +
                    " FROM PACIENTES WHERE EMAIL=?");
            ps.setString(1,email);
            ResultSet rs= ps.executeQuery();
            while (rs.next()){
                DomicilioDAOH2 domicilioDAOH2= new DomicilioDAOH2();
                domicilio=domicilioDAOH2.buscarXId(rs.getInt(7));
                paciente=new Paciente(rs.getInt(1),
                        rs.getString(2),rs.getString(3),
                        rs.getString(4),rs.getInt(5),
                        rs.getDate(6).toLocalDate(),domicilio
                );
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            try{
                connection.close();
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
        }
        return paciente;
    }

    @Override
    public Paciente buscarXId(int id) {
        return null;
    }
}
