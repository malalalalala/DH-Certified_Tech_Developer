package com.example.clinicadental.repository;

import com.example.clinicadental.model.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno,Integer> {
}
