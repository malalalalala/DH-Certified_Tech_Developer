package com.example.clinicadental.repository;

import com.example.clinicadental.model.Odontologo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OdontologoRepository extends JpaRepository<Odontologo,Integer> {
}
