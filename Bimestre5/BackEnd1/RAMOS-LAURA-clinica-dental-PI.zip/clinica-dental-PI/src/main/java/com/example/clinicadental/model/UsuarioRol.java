package com.example.clinicadental.model;

public enum UsuarioRol {
    USER,ADMIN
}
