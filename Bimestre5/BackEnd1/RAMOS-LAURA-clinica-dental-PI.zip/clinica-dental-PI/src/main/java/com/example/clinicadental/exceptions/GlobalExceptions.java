package com.example.clinicadental.exceptions;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

;

@ControllerAdvice
public class GlobalExceptions {

    public static final Logger logger=Logger.getLogger(GlobalExceptions.class);

    @ExceptionHandler({ResourceNotFoundException.class})
    public ResponseEntity<String> errorNotFoundHndler(ResourceNotFoundException ex){
        logger.error(ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error: "+ex.getMessage()+ "-GLOBAL");

    }

    @ExceptionHandler({SQLIntegrityViolationException.class})
    public ResponseEntity<String> errorSQLHndler(SQLIntegrityViolationException ex){
        logger.error(ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error: "+ex.getMessage()+ "-GLOBAL");

    }


}

