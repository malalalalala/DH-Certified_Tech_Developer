package ClaseIntegradoraRopa;

import java.util.ArrayList;
import java.util.List;

public class ListasRopa {
    List <DiseñoRopa> diseñoRopaList=new ArrayList<>();

    public void listarRopa(){
        System.out.println("Listando ropa...");
    }
}
