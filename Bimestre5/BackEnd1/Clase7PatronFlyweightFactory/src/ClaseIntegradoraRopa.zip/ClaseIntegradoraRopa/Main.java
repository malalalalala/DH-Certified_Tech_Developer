package ClaseIntegradoraRopa;

public class Main {
    private static String tallePrenda[]={"XS","S","M","l"};
    private static String origenPrenda[]={"Importada","Nacional"};
    private static String estadoPrenda[]={"Nueva","Usada"};


    public static void main(String[] args) {



    }
}
