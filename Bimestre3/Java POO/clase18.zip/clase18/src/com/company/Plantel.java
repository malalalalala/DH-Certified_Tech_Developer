package com.company;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Plantel {
    private Set<Jugador> jugadores;

    public Plantel() {
        this.jugadores = new HashSet<>();
    }

    public void agregarJugadores(Map<Jugador, String> jugadoresConvocados) {

    }
}
