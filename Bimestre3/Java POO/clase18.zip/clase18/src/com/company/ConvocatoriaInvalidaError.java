package com.company;

public class ConvocatoriaInvalidaError extends Exception {
    public ConvocatoriaInvalidaError(String message) {
        super(message);
    }
}
