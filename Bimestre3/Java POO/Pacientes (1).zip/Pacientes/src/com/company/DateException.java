package com.company;

public class DateException extends Exception{
    public DateException() {
        super();
    }

    public DateException(String s) {
        super(s);
    }
}
