package com.company;

public interface CalculableArea {
    public double getArea();
}
