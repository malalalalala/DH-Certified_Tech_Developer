package classes;

public abstract class Producto {
    private double peso;

    public abstract double calcularEspacio();
}
