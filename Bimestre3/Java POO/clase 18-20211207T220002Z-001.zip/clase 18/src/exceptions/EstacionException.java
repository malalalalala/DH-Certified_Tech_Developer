package exceptions;

public class EstacionException extends Exception {
    public EstacionException(String message) {
        super(message);
    }
}
