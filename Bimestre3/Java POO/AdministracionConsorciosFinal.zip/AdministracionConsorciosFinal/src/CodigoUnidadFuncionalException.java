public class CodigoUnidadFuncionalException extends Exception {
    public CodigoUnidadFuncionalException(String message) {
        super(message);
    }
}
