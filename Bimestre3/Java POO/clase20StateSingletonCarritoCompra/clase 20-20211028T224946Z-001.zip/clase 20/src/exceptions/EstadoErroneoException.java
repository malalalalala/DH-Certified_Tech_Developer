package exceptions;

public class EstadoErroneoException extends Exception {
    public EstadoErroneoException(String message) {
        super(message);
    }
}
