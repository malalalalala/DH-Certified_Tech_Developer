package exceptions;

public class ClientesException extends Exception{
    public ClientesException(String message) {
        super(message);
    }
}
