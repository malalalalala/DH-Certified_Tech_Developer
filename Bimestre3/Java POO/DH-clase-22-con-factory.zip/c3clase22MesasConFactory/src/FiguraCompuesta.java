import java.util.ArrayList;
import java.util.List;

public class FiguraCompuesta extends Figura{
	
	private List<Figura> figuras;

	
	public FiguraCompuesta() {
		figuras = new ArrayList<Figura>();
	}
	
	public void agregar(Figura f) {
		figuras.add(f);
	}


	public double calcularArea(){
		double area=0;
		
		for(Figura cadaUna:figuras)
			area += cadaUna.calcularArea();
		
		return area;
	}

}
