package com.company;

public interface EstadoReparacion {
    void valorPresupuesto(double presupuesto) throws Exception {}
    void cambiarDireccion(String direccion){

    }
    void agregarRepuesto(double costo){}
}
