package com.company;

public class EnPresupuesto implements EstadoReparacion{


    @Override
    public void valorPresupuesto(double presupuesto) {

    }

    @Override
    public void cambiarDireccion(String direccion) {

    }

    @Override
    public void agregarRepuesto(double costo) {

    }
}
