package com.company;

public class FactoryEstadoReparacion {

    public EstadoReparacion proximoEstado(EstadoReparacion estadoActual){
        return x;
    }


}
