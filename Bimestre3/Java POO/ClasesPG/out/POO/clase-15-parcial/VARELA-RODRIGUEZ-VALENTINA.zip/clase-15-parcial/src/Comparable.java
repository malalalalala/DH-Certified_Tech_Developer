public interface Comparable {
    int compareTo(Object o);
}
