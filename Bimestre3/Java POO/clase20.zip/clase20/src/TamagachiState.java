public interface TamagachiState {
    TamagachiState darDeBeber();
    TamagachiState darDeComer();
    TamagachiState darCaricias();
}
