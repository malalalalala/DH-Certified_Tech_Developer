package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Semaforo sema = new Semaforo();
        sema.mostrarAviso();
        sema.cambiarEstado();
        sema.mostrarAviso();
        sema.cambiarEstado();
        sema.mostrarAviso();
        sema.cambiarEstado();
        sema.mostrarAviso();
        sema.cambiarEstado();

    }
}
