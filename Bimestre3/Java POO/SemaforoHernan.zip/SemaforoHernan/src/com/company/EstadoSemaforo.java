package com.company;

public interface EstadoSemaforo {
    void mostrarAviso();
    void cambiarEstado();
}
