public interface Presupuestable {
    double calcularPrecioFinal();
}
