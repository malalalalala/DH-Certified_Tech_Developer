package com.company.interfaz;

public interface Calculable {
    double calcularAreaTotal();
}
