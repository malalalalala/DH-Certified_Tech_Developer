package com.company;

import java.util.List;

public class FactoryPizzas {

public static PizzaSimple crearPizzaSimple(String nombre, String descripcion, double precioBase, boolean grande) {
    return new PizzaSimple(nombre, descripcion, precioBase, grande);
}

public static PizzaCombinada crearPizzaCombinada(String nombre, String descripcion, List<PizzaSimple> pizzasSimples) {
    return new PizzaCombinada(nombre, descripcion, pizzasSimples);
}
}
