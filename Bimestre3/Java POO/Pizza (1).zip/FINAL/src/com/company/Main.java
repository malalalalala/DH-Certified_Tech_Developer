package com.company;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

    PizzaSimple simpleMuzza = FactoryPizzas.crearPizzaSimple("simpleMuzza", "Muzzarella", 700, false);
    PizzaSimple simpleEspecial = FactoryPizzas.crearPizzaSimple("simpleEspecial", "Especial", 850, false);
    PizzaSimple simpleAnana = FactoryPizzas.crearPizzaSimple("simpleAnana", "Anana", 950, false);
    List<PizzaSimple> Loca = new ArrayList<>();
    Loca.add(simpleEspecial);
    Loca.add(simpleAnana);
    PizzaCombinada combinadaLoca = FactoryPizzas.crearPizzaCombinada("combinadaLoca", "Especial y Anana", Loca);
    Pizzeria PL = new Pizzeria();
    PL.agregarPizzas(simpleAnana);
    PL.agregarPizzas(simpleEspecial);
    PL.agregarPizzas(simpleMuzza);
    PL.agregarPizzas(combinadaLoca);
    PL.mostrarPizzas();

    }
}
