package com.company;


import java.util.ArrayList;
import java.util.List;

public class Pizzeria {
    private List<Pizza> pizzas;

    public Pizzeria() {
        this.pizzas = new ArrayList<>();
    }

    public void agregarPizzas(Pizza pizza) {
        this.pizzas.add(pizza);
    }

    public void mostrarPizzas() {
        for (Pizza pizza : this.pizzas) {
            System.out.println(pizza);
        }
    }

}