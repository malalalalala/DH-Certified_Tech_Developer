package com.company;

import java.util.List;
import java.util.Set;

public class PizzaCombinada extends Pizza{
    private List<PizzaSimple> pizzas;

    public PizzaCombinada(String nombre, String descripcion, List<PizzaSimple> pizzas) {
        super(nombre, descripcion);
        this.pizzas = pizzas;
    }

    @Override
    public double calcularPrecio() {
        double totalPrecio = 0;
        int totalPizzas;
        double precio;
        for (PizzaSimple Pizza : this.pizzas) {
            totalPrecio += Pizza.calcularPrecio();
        }
        totalPizzas = pizzas.size();
        return precio = totalPrecio/totalPizzas;
    }

    @Override
    public String toString() {
        return super.getNombre() + " $ " + this.calcularPrecio();
}
}
