package com.company;

public class PizzaSimple extends Pizza{
    private double precioBase;
    private boolean grande;

    public PizzaSimple(String nombre, String descripcion, double precioBase, boolean grande) {
        super(nombre, descripcion);
        this.precioBase = precioBase;
        this.grande = grande;
    }

    @Override
    public double calcularPrecio() {
        if (grande) {
            return precioBase*2;
        } else {
            return precioBase;
        }
    }
    @Override
    public String toString() {
        return super.getNombre() + " $ " + this.calcularPrecio();
    }
}
