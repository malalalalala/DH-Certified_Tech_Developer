package poo.varela;

public class CarreraCargaHorariaCursoException extends Exception {
    public CarreraCargaHorariaCursoException(String mensaje) {
        super(mensaje);
    }
}
