public class CodigoCargaSimpleExcepcion extends Exception {
    public CodigoCargaSimpleExcepcion(String message) {
        super(message);
    }
}
