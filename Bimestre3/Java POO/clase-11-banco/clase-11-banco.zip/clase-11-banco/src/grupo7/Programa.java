package grupo7;

public class Programa {
    public static void main(String[] args) {
        Cliente pepe = new Cliente(1, "Pepardo", 23000000, 230000006);
        CajaDeAhorro cajaDeAhorro = new CajaDeAhorro(50000, pepe, 15);
        CuentaCorriente cuentaCorriente = new CuentaCorriente(35000, pepe, 20000);

        probar(pepe);
        probar(cajaDeAhorro);
        probar(cuentaCorriente);
    }

    public static void probar(Cliente cliente) {
        System.out.println("\n\n-----------------------------------------------------------------");
        System.out.println("------------------------------ CLIENTE -----------------------------");
        System.out.println("-----------------------------------------------------------------");
        System.out.println(cliente.toString());
        cliente.irAlBanco();
        cliente.quejarse();
        cliente.esperarEternamente();
    }

    public static void probar(CajaDeAhorro caja) {
        System.out.println("\n\n-----------------------------------------------------------------");
        System.out.println("------------------------- CAJA DE AHORRO ------------------------");
        System.out.println("-----------------------------------------------------------------");
        System.out.println("El interés cobrado es: $" + caja.cobrarInteres());
        caja.extraer(15000);
        caja.extraer(10000);
        System.out.println("El interés cobrado es: $" + caja.cobrarInteres());
        caja.depositar(2000);
        caja.extraer(40000);
    }

    public static void probar(CuentaCorriente cuenta) {
        System.out.println("\n\n-----------------------------------------------------------------");
        System.out.println("------------------------ CUENTA CORRIENTE -----------------------");
        System.out.println("-----------------------------------------------------------------");
        cuenta.depositar(5000);
        cuenta.extraer(10000);
        cuenta.extraer(30000);
        cuenta.extraer(25000);
        cuenta.extraer(20000);

    }
}
