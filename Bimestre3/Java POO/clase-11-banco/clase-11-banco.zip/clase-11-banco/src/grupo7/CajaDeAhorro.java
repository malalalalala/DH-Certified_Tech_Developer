package grupo7;

public class CajaDeAhorro extends Cuenta {

    private double tasaInteres;

    public CajaDeAhorro(double saldo, Cliente cliente, double tasaInteres) {
        super(saldo, cliente);
        this.tasaInteres = tasaInteres;
    }

    @Override
    public void extraer(double monto) {
        System.out.println("\nIntentando extraer: $" + monto);
        if (monto <= getSaldo()) {
            System.out.println("La operación se realizó con éxito, ud. extrajo: $" + monto);
            setSaldo(getSaldo() - monto);
        } else {
            System.out.println("El saldo de la cuenta es insuficiente, F");
        }
    }

    public double cobrarInteres() {
        return this.tasaInteres * getSaldo();
    }
}
