package poo.varela;

public class TipoDeServicioIncorrectoException extends IllegalStateException {
    public TipoDeServicioIncorrectoException(String mensaje) {
        super(mensaje);
    }
}
