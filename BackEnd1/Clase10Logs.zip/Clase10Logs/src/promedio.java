//import java.util.List;
//
//public class promedio {
//
//   public static double calcularPromedio(List list){
//       int acumulador = 0;
//       for (int i=0;i<=list.size();i++){
//           acumulador+= (int) list.get(i);
//       }
//
//   }
//}
