package com.example.C32S;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C32SApplicationTests {

	@Test
	void contextLoads() {
	}

}
