package com.example.C32S.dto;

public class RestarCantidadDTO {

    public int getCantidad() {
        return cantidad;
    }

    private int cantidad;

}
