## Run the project
This is a project created to help you to be sure you have all you will need for your onsite.

There are 3 scripts you can use to build, run and test the project with NPM:

- test.sh: Run unit tests in the project
- run.sh: Runs the project. You can see the app in `localhost:3000/hello`